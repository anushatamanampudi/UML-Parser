/**
 * 
 */


/**
 * @author anushatamanampudi
 *
 */


import japa.parser.JavaParser;
import japa.parser.ast.CompilationUnit;
import japa.parser.ast.body.BodyDeclaration;
import japa.parser.ast.body.ClassOrInterfaceDeclaration;
import japa.parser.ast.body.ConstructorDeclaration;
import japa.parser.ast.body.EmptyMemberDeclaration;
import japa.parser.ast.body.EmptyTypeDeclaration;
import japa.parser.ast.body.FieldDeclaration;
import japa.parser.ast.body.InitializerDeclaration;
import japa.parser.ast.body.MethodDeclaration;
import japa.parser.ast.body.TypeDeclaration;
import japa.parser.ast.body.VariableDeclarator;
import japa.parser.ast.body.VariableDeclaratorId;
import japa.parser.ast.expr.ObjectCreationExpr;
import japa.parser.ast.expr.VariableDeclarationExpr;
import japa.parser.ast.stmt.BlockStmt;
import japa.parser.ast.stmt.TypeDeclarationStmt;
import japa.parser.ast.type.ClassOrInterfaceType;
import japa.parser.ast.type.PrimitiveType;
import japa.parser.ast.type.Type;
import japa.parser.ast.visitor.VoidVisitorAdapter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Umlparser {

	/**
	 * @param args
	 */
	//s is the string passed as input for the plantuml which contains the format required by plantuml
	public static String s = "@startuml\n";// Format required by plantuml.
	//list having all the java files.
	public static  List<String> listoffiles = new ArrayList<String>();
	//get the name of the class or interface
	public static String classorinterfacename;
	 //get all the methods in the class. Using this to check getters and setters and ignore them without printing in operations group
	public static List<String> ar ;
	//get the variables set by getter in order to change its access modifier in case its private and setter and getter is public
	public static List gettervariables ; 
	// Checked only public methods for a class so this is used to check if its an interface and adds all the methods. Not only public in case of interface. 
	public static int isinterface;
	public static Map<String, String> classmap;
	public static Map<String, String> collectionmap;
	public static List<String> interfacelist = new  ArrayList<String>();
	public static List<String> initvariables ;
	public static List<String> objectcreatedclasseslist;
	public static void main(String[] args) throws Exception {
		// Get all the java files in the package and take their name into a list.
		File Directory = new File(args[0]); 
		  //File Directory = new File("/Users/anushatamanampudi/Documents/uml-parser-test-5");
			 File[] Javafiles = Directory.listFiles();
		

		     for (int i = 0; i < Javafiles.length; i++) {
		       
		       String  k= Javafiles[i].getName();
		       
		       if(k.contains(".java")){
		       k = k.replace(".java","");
		       listoffiles.add(k);
		       }
		     }
		    
		     for(File f1: Javafiles){
		    	 if(f1.getName().contains(".java")){
		    		 FileInputStream in1 = new FileInputStream(f1);//read the file
						CompilationUnit cu1;
						try {
				            
				            cu1 = JavaParser.parse(in1); //Takes all the code to compilation unit (Unit of java parser)
				        } finally {
				            in1.close();
				        } 
						List types1 = cu1.getTypes();
						TypeDeclaration typeDec1 = (TypeDeclaration) types1.get(0);//Get the classes or interfaces
						 ClassOrInterfaceDeclaration decl1 = (ClassOrInterfaceDeclaration) typeDec1;//decl is used to check isInterface method
						
						 if(decl1.isInterface())
						 {
							interfacelist.add(decl1.getName());
					     
						 }
						 
						
						 
						 
						
		    	 }
		     }
		     //Iterate through the list and for each java program get the class name and append to the string
		     
		     for (File f : Javafiles) { 
		    	 
		    	 if(f.getName().contains(".java")){//ignore files other than .java
		    		 isinterface=0;//for classes isinterface is '0' and for interface its set to 1.
		    		 ar =new ArrayList<String>();//creating getter setter array for each program
		    		 gettervariables =new ArrayList<String>();//creating attribute array for each program
		    		 collectionmap=new HashMap<String, String>();
		    		 classmap=new HashMap<String, String>();
		    		 initvariables=new  ArrayList<String>();
		    		 objectcreatedclasseslist=new  ArrayList<String>();
					FileInputStream in = new FileInputStream(f);//read the file
					CompilationUnit cu;
					try {
			            
			            cu = JavaParser.parse(in); //Takes all the code to compilation unit (Unit of java parser)
			        } finally {
			            in.close();
			        }
					List types = cu.getTypes();
					TypeDeclaration typeDec = (TypeDeclaration) types.get(0);//Get the classes or interfaces
					 ClassOrInterfaceDeclaration decl = (ClassOrInterfaceDeclaration) typeDec;//decl is used to check isInterface method
					if(decl.isInterface())
					 {
						classorinterfacename = decl.getName();
				      s = s + "interface" + " " + classorinterfacename  + "\n";
				   
				       isinterface = 1;
					 }
					 else
					 {
						 classorinterfacename = decl.getName();
				       s = s + "class" + " " + classorinterfacename  + "\n";
				       
					}
					
					
					
					new MethodVisitor1().visit(cu, null);//gets all the methods that are public and stores in ar
		
					new Objectcreationcheck().visit(cu,null);//checks for objects that are created inside the class
					new MethodVisitorextra().visit(cu,null);// to add objects that are created in method body.
					//appends the methods which are
					//1)public 2)not a setter or getter 3)if its a main method (has id 9 in javaparser) 4)all methods in case of interface
				   //Also appends the parameters if there are any for the given method.
					new ExtendVisitor().visit(cu, null);
					//checks for implements relationship between classes.
					new Impl().visit(cu,null);
					//checks for uses relationship
								
					new MethodVisitor().visit(cu, null);
		//Appends Contstructor method and its parameters.
					new MethodVisitorCon().visit(cu, null);
					new FieldVisitor2().visit(cu,null);
		
		//checks for extends relationship between classes.
					new FieldVisitor1().visit(cu, null);
					// 1) gets all the attributes of a class which are
					// 2) are public or private
				    // 3) in case of private, checks if its a getter variable and makes it public
					// 4)ignores objects of other classes both single object or collections
								
					new FieldVisitor().visit(cu, null);
					
					
					
					new uses().visit(cu,null);
					
				
		              
		    	 }
		     }
		
		    s = s + "@enduml\n";
		    
		   
		    //
		    //System.out.println( Arrays.asList(s.split("\n")));
	        
		    
		 //Calling the plant uml object in order to pass the string 's' as input.
		
	//printing in order to check the output.
	 
	 
	
	
	 String[] words = s.split("\\r?\\n"); 
	 Set<String> set = new HashSet<String>();
	for(String check : words){ 
		 check=check.toString();
		   
			if(check.contains(" ") && check.contains("<") && check.contains("\"")){
				 String last;
					String first;
			first=check.substring(0,check.indexOf(" "));
			//System.out.println(first);
			last=check.substring(check.lastIndexOf(" ")+1,check.length());
			//System.out.println(last);
			
			String arrow=check.substring(check.lastIndexOf("\"")+2,check.lastIndexOf(" "));
			//System.out.println(arrow);
			String cardinality = check.substring(check.indexOf(" ")+2,check.lastIndexOf("\""));
			//System.out.println(cardinality);
			String s3=check.replace(last,first);
			String s2=s3.replaceFirst(first,last);
			String cardinality1;
			if(cardinality.equals("0...*")){
				cardinality1="1";
			}
			else{
				cardinality1="0...*";
			}
			String s1=s2.replace(cardinality, cardinality1);
			String s4=check.replace(cardinality, cardinality1);
		 if(!set.add(check) && (!check.equals("skinparam classAttributeIconSize 0")))
		 { 
			 s=s.replaceFirst(check,"");
		 }
		 if(s.contains(s2)){
			 s=s.replaceFirst(s2,"");
			 s=s.replaceFirst(check,check.replace(arrow, arrow+">"+"\""+cardinality+"\""));
		 }
		 if(s.contains(s1)){
			 s=s.replaceFirst(s1,"");
			 s=s.replaceFirst(check,check.replace(arrow, arrow+">"+"\""+cardinality1+"\""));
		 }
		 if(s.contains(s4)){
			 
			 if(cardinality.toString().equals("1")){
				 s=s.replace(check,"");
				 
			 }
			 else{
				  
			 }
		 }
		 
		 
	 
			}
			
			else{
				if(check.contains(" ") && check.contains("<")){
					
					String last;
					String first;
			first=check.substring(0,check.indexOf(" "));
			//System.out.println(first);
			last=check.substring(check.lastIndexOf(" ")+1,check.length());
			//System.out.println(last);
			
			String arrow=check.substring(check.indexOf(" ")+1,check.lastIndexOf(" "));
			//System.out.println("hello"+arrow);
			
			String s3=check.replace(last,first);
			String s2=s3.replaceFirst(first,last);
			
			
		 if(!set.add(check) && (!check.equals("skinparam classAttributeIconSize 0")))
		 { 
			 s=s.replaceFirst(check,"");
		 }
		 if(s.contains(s2)){
			 s=s.replaceFirst(s2,"");
			 s=s.replaceFirst(check,check.replace(arrow, arrow+">"));
		 }
		
		 
					
				}
			}
	 
	 }


     System.out.println(s);
     test p = new test();
		p.umlgen(s,args[1]);
		

	}
	
	 /**
     * Simple visitor implementation for visiting MethodDeclaration nodes. 
     */
  private static class MethodVisitor1 extends VoidVisitorAdapter {
	 
	public void visit(MethodDeclaration n, Object arg) {
       
		  
    	 String[] a={"","+","-","","",}; // maps the id's used in javaparser for the respective access modifiers.
    	 
    	 if(n.getModifiers()==1){
    		 
          ar.add(n.getName()); //array containing all the methods in order to be checked for getters and setters
        
    		 

    	 }
    	
    }
	
  }
  
  
  private static class Objectcreationcheck extends VoidVisitorAdapter {
		 
		public void visit(ObjectCreationExpr n, Object arg) {
		if(n.getType().getTypeArgs()!=null){
			System.out.println("creation"+n.getType().getTypeArgs());
	     objectcreatedclasseslist.add(n.getType().getTypeArgs().toString()); 
		}
	    //System.out.println("creation"+n.getType().getTypeArgs());
	       
	    		 

	    	 }
	    	
	    
		
	  }
    private static class MethodVisitor extends VoidVisitorAdapter {
    	
    	
        public void visit(MethodDeclaration n, Object arg) {
            
        	 String[] a={"","+","-","","",};
        	 String check =n.getName();
       //used to change string the get to type set and set to get. Eg: if we find geta we search for seta and if matches we ignore these methods.
        	
        	 
        	 if(isinterface==1){
        		 if(n.getParameters() != null){//get parameters if exists and add inside () string else  add () only
            		 String ab = null;
            		 String ab1=null;
            		 if(n.getParameters().get(0).getType().toString().contains("Collection")){
            			 
            			ab=n.getParameters().get(0).getType().toString().substring(11,n.getParameters().get(0).getType().toString().length()-1);
            			ab1="0...*";
            		 }
            		 else{
            			 ab=n.getParameters().get(0).getType().toString();
            			 ab1="1";
            		 }
            		
            		 if(listoffiles.contains(ab)){
            			
              		    
            			//s = s + ab +" "+"\""+ab1+"\""+" "+"--" + " " + classorinterfacename + "\n";
            			s= s+ "skinparam classAttributeIconSize 0"+"\n";//used for representation of accessmodifiers as +,- etc..
        	        	s = s + classorinterfacename + " : " +"+"+ n.getName() + "("+n.getParameters().get(0).getId()+":"+ n.getParameters().get(0).getType()+")"+ " : "+ n.getType();
        	            s = s + "\n"; 
     			    }
        			    else{
        	            s= s+ "skinparam classAttributeIconSize 0"+"\n";//used for representation of accessmodifiers as +,- etc..
        	        	s = s + classorinterfacename + " : " +"+"+ n.getName() + "("+n.getParameters().get(0).getId()+":"+ n.getParameters().get(0).getType()+")"+ " : "+ n.getType();
        	            s = s + "\n";
        			    }
        	            	 }
        	            	 else{
        	            		 
        	            		 s= s+ "skinparam classAttributeIconSize 0"+"\n";
        	                 	s = s + classorinterfacename + " : " +"+"+ n.getName() + "()"+ " : "+ n.getType();
        	                     s = s + "\n";
        	            	 }
        	 }
        	//n.getmodifiers==9 checks for public static methods
        	 else if(n.getModifiers()==1){
             if(check.startsWith("get")){
            	 check.replace("get", "set");
            	int i=n.getBody().toString().indexOf("return");
            	String b=n.getBody().toString().substring(i+7);//get the attribute that get method returns excluding return from the statement
            	int j=b.indexOf(";");
            	String f=b.substring(0,j);
            	
            	if(f.contains("this."))
            	{
            		f=f.substring(5);
            	}
            	gettervariables.add(f);
    
             }
             else if(check.startsWith("set")){
            	 
            	check.replace("set", "get");
             }
             else{
            	 
            	 check=null; //used for other methods other than get set to avoid null pointer exception
             }
             if(ar.contains(check)){
            	 
             }
             else{
            	 if(n.getParameters() != null){
            		 String ab = null;
            		 String ab1=null;
            		 if(n.getParameters().get(0).getType().toString().contains("Collection")){
            			 
            			ab=n.getParameters().get(0).getType().toString().substring(11,n.getParameters().get(0).getType().toString().length()-1);
            			ab1="0...*";
            		 }
            		 else{
            			 ab=n.getParameters().get(0).getType().toString();
            			 ab1="1";
            		 }
            		 
            		 if(listoffiles.contains(ab)){
            			
              		    if(interfacelist.contains(ab)){
              		    	
              		    
              		  //  if(check(ab +" "+"\""+ab1+"\""+" "+"<.." + " " + classorinterfacename,s)==0){	
              		    	
            			s = s + ab +" "+"\""+ab1+"\""+" "+"<.." + " " + classorinterfacename + "\n";
              		    			
              		  //  }	
              		    	
              		    }
              		    else{
              		    	//if(check(ab +" "+"\""+ab1+"\""+" "+"<--" + " " + classorinterfacename,s)==0){
              		    		
              		    	s = s + ab +" "+"\""+ab1+"\""+" "+"<--" + " " + classorinterfacename + "\n";
              		    	//}
              		    }
            			s= s+ "skinparam classAttributeIconSize 0"+"\n";
                    	s = s + classorinterfacename + " : " +a[n.getModifiers()]+ n.getName() + "("+n.getParameters().get(0).getId()+":"+ n.getParameters().get(0).getType()+")"+ " : "+ n.getType();
                        s = s + "\n";
            			 
     			    }
            		 else{
            s= s+ "skinparam classAttributeIconSize 0"+"\n";
        	s = s + classorinterfacename + " : " +a[n.getModifiers()]+ n.getName() + "("+n.getParameters().get(0).getId()+":"+ n.getParameters().get(0).getType()+")"+ " : "+ n.getType();
            s = s + "\n";
            		 }
            	 }
            	 else{
            		 
            		 s= s+ "skinparam classAttributeIconSize 0"+"\n";
                 	s = s + classorinterfacename + " : " +a[n.getModifiers()]+ n.getName() + "()"+ " : "+ n.getType();
                     s = s + "\n";
            	 }
        	 }
        }
       else if(n.getModifiers()==9){
    	   
    	   
    	   
    	   
    	   if(n.getParameters() != null){
       		
               s= s+ "skinparam classAttributeIconSize 0"+"\n";
           	s = s + classorinterfacename + " : " +"+"+ n.getName() + "("+n.getParameters().get(0).getId()+":"+ n.getParameters().get(0).getType()+")"+ " : "+ n.getType();
               s = s + "\n";
               	 }
               	 else{
               		 
               		 s= s+ "skinparam classAttributeIconSize 0"+"\n";
                    	s = s + classorinterfacename + " : " +"+"+ n.getName() + "()"+ " : "+ n.getType();
                        s = s + "\n";
               	 }
        	 }
   
      
    }
    }
    
    //to add constructor
private static class MethodVisitorCon extends VoidVisitorAdapter {
	String[] a={"","+","-","","",};
	
	public void visit(ConstructorDeclaration n, Object arg) {
		
		 if(n.getParameters() != null){
			 String ab = null;
    		 String ab1=null;
    		 if(n.getParameters().get(0).getType().toString().contains("Collection")){
    			 
    			ab=n.getParameters().get(0).getType().toString().substring(11,n.getParameters().get(0).getType().toString().length()-1);
    			
    			ab1="0...*";
    		 }
    		 else{
    			 ab=n.getParameters().get(0).getType().toString();
    			 ab1="1";
    		 }
    		 if(listoffiles.contains(ab)){
    			
      		    
    			 if(interfacelist.contains(ab)){
    				
         			s = s + ab +" "+"\""+ab1+"\""+" "+"<.." + " " + classorinterfacename + "\n";
    				
    					 
    				 
           		    }
           		    else{
           		    	
           		    			
           		    	s = s + ab +" "+"\""+ab1+"\""+" "+"<--" + " " + classorinterfacename + "\n";
           		    	
           		    	
           		    	
           		    }
         			s= s+ "skinparam classAttributeIconSize 0"+"\n";
 	        	s = s + classorinterfacename + " : " +a[n.getModifiers()]+ n.getName() + "("+n.getParameters().get(0).getId()+":"+ n.getParameters().get(0).getType()+")";
 	            s = s + "\n";
    			 
			    }
    		 else{
			 System.out.println("param"+n.getParameters());
			 s= s+ "skinparam classAttributeIconSize 0"+"\n";
	        	s = s + classorinterfacename + " : " +a[n.getModifiers()]+ n.getName() + "("+n.getParameters().get(0).getId()+":"+ n.getParameters().get(0).getType()+")";
	            s = s + "\n";
    		 }
		 }
		 else{
			 s= s+ "skinparam classAttributeIconSize 0"+"\n";
		    	s = s + classorinterfacename + " : " +a[n.getModifiers()]+ n.getName() + "()";
		        s = s + "\n";
		 }
     }
}


private static class MethodVisitorextra extends VoidVisitorAdapter {
	
	
	public void visit(VariableDeclarationExpr n, Object arg) {
		 String[] a={"","+","-","","",};
         String[] types = {"int[]", "String[]", "boolean[]", "char[]", "float[]","short[]","double[]","String"};  
       //System.out.println("hell"+n.getVars().get(0).getId());
       	if(n.getType().toString().contains("Collection")){
       		 
       		collectionmap.put(n.getType().toString().substring(11,(n.getType().toString().length()-1)),n.getVars().get(0).getId().toString());
       	}
       	
       	//if the attributes are not class objects add them to the string
       	
                        //checking for reference type excludes string and int[] ,float[] etc..also  so further checking
                        // to confirm if its userdefined class object or java inbuilt userdefined object.
       		
       	     
       	else if(n.getType().getClass().getSimpleName().equals("ReferenceType")){
        			    
        				if(Arrays.asList(types).contains(n.getType().toString())){

        					
        				}
        			    else{
        			 	
        			    	
        	        		classmap.put(n.getType().toString(),n.getVars().get(0).getId().toString());
        	        		
 
               

        					
       		}
               
       	}
		
	}
	
	
	 
	 
}









    private static class FieldVisitor extends VoidVisitorAdapter {

        @Override
        public void visit(FieldDeclaration n, Object arg) {
        	
        	 
          String[] a={"","+","-","","",};
          if(n.getModifiers()==1||n.getModifiers()==2){
        	  
        	if(n.getType().toString().contains("Collection")){
        		if(gettervariables.contains(n.getVariables().toString())){
        		if(listoffiles.contains(n.getType().toString().substring(11,(n.getType().toString().length()-1)))){
        			
        		}
        		else{
        			s= s+ "skinparam classAttributeIconSize 0";
            	    s = s + "\n";
            		s = s + classorinterfacename + " : " + a[1]+n.getVariables().get(0).getId().toString()+":"+n.getType().toString().substring(11,(n.getType().toString().length()-1));
                    s = s + "\n";
        		}
        	}
        		else{
        			if(listoffiles.contains(n.getType().toString().substring(11,(n.getType().toString().length()-1)))){
            			
            		}
            		else{
            			s= s+ "skinparam classAttributeIconSize 0";
                	    s = s + "\n";
                		s = s + classorinterfacename + " : " + a[n.getModifiers()]+n.getVariables().get(0).getId().toString()+":"+n.getType().toString().substring(11,(n.getType().toString().length()-1));
                        s = s + "\n";
            		}
        		}
        		
        	
        	
        	
        	
        	}
        	//if the attributes are not class objects add them to the string
        	else{
       //checking for reference type excludes string and int[] ,float[] etc..also  so further checking
       // to confirm if its userdefined class object or java inbuilt userdefined object.
        		String[] types = {"int[]", "String[]", "boolean[]", "char[]", "float[]","short[]","double[]","String"};
        		
        		if(gettervariables.contains(n.getVariables().get(0).getId().toString())){
        			
        			 if(n.getType().getClass().getSimpleName().equals("ReferenceType")){
         			    
         				if(Arrays.asList(types).contains(n.getType().toString())){
                            
         					s= s+ "skinparam classAttributeIconSize 0";
                    	    s = s + "\n";
                    		s = s + classorinterfacename + " : " + a[1]+n.getVariables().get(0).getId().toString()+":"+n.getType();
                            s = s + "\n";
         				}
                        else if(listoffiles.contains(n.getType().toString())){
         					
         				}
         				else{
         					s= s+ "skinparam classAttributeIconSize 0";
                    	    s = s + "\n";
                    		s = s + classorinterfacename + " : " + a[1]+n.getVariables().get(0).getId().toString()+":"+n.getType();
                            s = s + "\n";
         				}
         			}
        			 if(n.getType().getClass().getSimpleName().equals("PrimitiveType")){
        				 s= s+ "skinparam classAttributeIconSize 0";
        				 s = s + "\n";
                 		s = s + classorinterfacename + " : " + a[1]+n.getVariables().get(0).getId().toString()+":"+n.getType();
                         s = s + "\n";
        			 }
        			
        		}
        		else{	
        		
  
             if(n.getType().getClass().getSimpleName().equals("ReferenceType")){
         			    
         				if(Arrays.asList(types).contains(n.getType().toString())){

         					s= s+ "skinparam classAttributeIconSize 0";
                    	    s = s + "\n";
                    		s = s + classorinterfacename + " : " + a[n.getModifiers()]+n.getVariables().get(0).getId().toString()+":"+n.getType();
                            s = s + "\n";
         				}
         				else if(listoffiles.contains(n.getType().toString())){
         					
         				}
         				else{
         					s= s+ "skinparam classAttributeIconSize 0";
                    	    s = s + "\n";
                    		s = s + classorinterfacename + " : " + a[n.getModifiers()]+n.getVariables().get(0).getId().toString()+":"+n.getType();
                            s = s + "\n";
         				}
         			}
        			 if(n.getType().getClass().getSimpleName().equals("PrimitiveType")){
        				 s= s+ "skinparam classAttributeIconSize 0";
        				 s = s + "\n";
                 		s = s + classorinterfacename + " : " + a[n.getModifiers()]+n.getVariables().get(0).getId().toString()+":"+n.getType();
                         s = s + "\n";
        			 } 
        		}
                
        	}
        	
        }}
    }
    
    private static class FieldVisitor1 extends VoidVisitorAdapter {

        @Override
        public void visit(FieldDeclaration n, Object arg) {
        	
        	 
          String[] a={"","+","-","","",};
          String[] types = {"int[]", "String[]", "boolean[]", "char[]", "float[]","short[]","double[]","String"};  
           
        	if(n.getType().toString().contains("Collection")){
        		 
        		collectionmap.put(n.getType().toString().substring(11,(n.getType().toString().length()-1)),n.getVariables().get(0).getId().toString());
        	}
        	
        	//if the attributes are not class objects add them to the string
        	
                         //checking for reference type excludes string and int[] ,float[] etc..also  so further checking
                         // to confirm if its userdefined class object or java inbuilt userdefined object.
        		
        	     
        	else if(n.getType().getClass().getSimpleName().equals("ReferenceType")){
         			    
         				if(Arrays.asList(types).contains(n.getType().toString())){

         					
         				}
         			    else{
         			 	
         			    	
         	        		classmap.put(n.getType().toString(),n.getVariables().get(0).getId().toString());
         	        		
  
                

         					
        		}
                
        	}
        	
        }
        
    }
    
    private static class FieldVisitor2 extends VoidVisitorAdapter {

        @Override
        public void visit(FieldDeclaration n, Object arg) {
        	
        	 
           
        	if(n.getVariables().get(0).getInit() != null){
        		  
            	   initvariables.add(n.getVariables().toString().substring(1,(n.getVariables().toString().indexOf("=")-1)));
            	   
          }
        	  
        	
        	     
        	
        	
        }
        
    }
    
    
    private static class ExtendVisitor extends VoidVisitorAdapter {

    	
		 @Override
		 public void visit(ClassOrInterfaceDeclaration decl, Object arg)
		   {
		      
			 
			 List<ClassOrInterfaceType> list = decl.getExtends();
			 if(list==null)
				 return;
			 for (ClassOrInterfaceType k : list) {
					String n = k.toString();
				   if(collectionmap.containsKey(n)){
					   
					s = s + n +" "+"\""+"0...*"+"\""+" "+"<|--" + " " + classorinterfacename + "\n";
					   
				   }
				   else if(classmap.containsKey(n)){
					 
					   s = s + n +" "+"\""+"1"+"\""+" "+"<|--" + " " + classorinterfacename + "\n";
					   
				   }
				   else{
					  
					   s = s + n +" "+"<|--" + " " + classorinterfacename + "\n";
					   
				   }
					
				}
		      
		      
		   }
    }
	private static class Impl extends VoidVisitorAdapter {

		
    	
	
			 @Override
			 public void visit(ClassOrInterfaceDeclaration decl, Object arg)
			   {
				 
				 
				 List<ClassOrInterfaceType> list = decl.getImplements();
				
				 if(list==null)
					 return;
				 for (ClassOrInterfaceType k : list) {
						String n = k.toString();
						if(collectionmap.containsValue(n)){
							
							s = s + n +" "+"\""+"0...*"+"\""+" "+"<|.." + " " + classorinterfacename + "\n";
							
						}
						 else if(classmap.containsKey(n)){
							 
							   s = s + n +" "+"\""+"1"+"\""+" "+"<|.." + " " + classorinterfacename + "\n";
							 
						   }
						 else{
							
							   s = s + n +" "+"<|.." + " " + classorinterfacename + "\n";
							 
						   }
					}
				
			      
			      
			   }
		 }
	
	private static class uses extends VoidVisitorAdapter {
		
	      
		 @Override
		 public void visit(ClassOrInterfaceDeclaration decl, Object arg)
		   {
			// System.out.println("dcl"+decl.getName());
			 
			 List<String> collist=new ArrayList<String>();
			 collist.addAll(collectionmap.keySet());
			
			 if(!collist.isEmpty()){
			 for(String k:collist){
				 
				 if(interfacelist.contains(k)){
					
					 if(objectcreatedclasseslist.contains("["+k+"]")){
							s = s + k +" "+"\""+"0...*"+"\""+" "+"<--" + " " + classorinterfacename + "\n";
						}
					 else{
					 s = s + k +" "+"\""+"0...*"+"\""+" "+"<.." + " " + classorinterfacename + "\n";
					 }
							
					
				 }
				 else{
					
					
					
						
							 
						s = s + k +" "+"\""+"0...*"+"\""+" "+"<--" + " " + classorinterfacename + "\n";
										
						
						 
					
						
						
					}
				 }
				 
				 
			 }
			 
			 
		   
		///check if the class creates objects or just uses it.   do both 0....* and 1 cases    
			 List<String> clslist=new ArrayList<String>();
			 clslist.addAll(classmap.keySet());
			// System.out.println("hey"+classmap);
			 if(!clslist.isEmpty()){
			 for(String k:clslist){
				 
				 if(interfacelist.contains(k)){
					 if(objectcreatedclasseslist.contains("["+k+"]")){
						 s = s + k +" "+"\""+"1"+"\""+" "+"<--" + " " + classorinterfacename + "\n";	
						}
						else{
					 s = s + k +" "+"\""+"1"+"\""+" "+"<.." + " " + classorinterfacename + "\n";
						}
					
					
				 }
				 else{ 
					
						
						s = s + k +" "+"\""+"1"+"\""+" "+"<--" + " " + classorinterfacename + "\n";
						
						
					
				 
			 }
			 
			 
		   }
			 
		   
		   
		   
		   
		   
		   
		   }
			
		   }
		      
		      
		   
	 }
		        
	        
}

	


